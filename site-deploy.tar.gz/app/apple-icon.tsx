import { ImageResponse } from 'next/og'

export const size = { width: 180, height: 180 }
export const contentType = 'image/png'

export default function AppleIcon() {
  return new ImageResponse(
    (
      <div
        style={{
          width: '100%',
          height: '100%',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          background: '#f7f5f0',
        }}
      >
        <div style={{ width: 84, height: 84, borderRadius: '50%', background: '#9b3312' }} />
      </div>
    ),
    size
  )
}
